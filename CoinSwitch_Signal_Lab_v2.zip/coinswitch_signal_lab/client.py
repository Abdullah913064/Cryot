"""READ-ONLY CoinSwitch futures API client. No order placement methods."""
import os
import time
from collections import deque
from urllib.parse import urlencode,unquote_plus
import requests
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

BASE='https://coinswitch.co'
ROOT='/trade/api/v2/futures'

class CoinSwitchClient:
    def __init__(self):
        self.key=os.getenv('COINSWITCH_API_KEY','').strip()
        self.secret=os.getenv('COINSWITCH_SECRET_KEY','').strip()
        if not self.key or not self.secret:
            raise ValueError('Set COINSWITCH_API_KEY and COINSWITCH_SECRET_KEY environment variables. Do not paste keys into chat.')
        if len(bytes.fromhex(self.secret))!=32:
            raise ValueError('CoinSwitch private key should be a 32-byte Ed25519 hex seed')
        self.private=Ed25519PrivateKey.from_private_bytes(bytes.fromhex(self.secret))
        self.http=requests.Session()
        self.kline_calls=deque()
        self._klines_cache={}  # cache immutable completed-timeframe reads within a candle interval

    def _get(self,path,params=None,kline=False):
        if kline:
            # A rolling limiter with safety headroom: 28 of documented 30 / 60 sec.
            while True:
                now=time.monotonic()
                while self.kline_calls and now-self.kline_calls[0]>=61:
                    self.kline_calls.popleft()
                if len(self.kline_calls)<28:
                    self.kline_calls.append(now)
                    break
                time.sleep(min(2,max(.2,61-(now-self.kline_calls[0]))))
        raw=path+('?' + urlencode(params) if params else '')
        signed=unquote_plus(raw)
        for attempt in range(3):
            # Re-sign for each retry: API timestamps expire quickly.
            epoch=str(int(time.time()*1000))
            signature=self.private.sign(('GET'+signed+epoch).encode()).hex()
            headers={'Content-Type':'application/json','X-AUTH-APIKEY':self.key,
                     'X-AUTH-SIGNATURE':signature,'X-AUTH-EPOCH':epoch}
            try:
                r=self.http.get(BASE+raw,headers=headers,timeout=15)
                if r.status_code==429 and attempt<2:
                    time.sleep(5*(attempt+1));continue
                r.raise_for_status()
                obj=r.json()
                if not isinstance(obj,dict) or 'data' not in obj:
                    raise ValueError('Unexpected API response: '+str(obj)[:150])
                return obj
            except (requests.exceptions.Timeout,requests.exceptions.ConnectionError):
                if attempt==2:raise
                time.sleep(1+attempt*2)
        raise RuntimeError('Request failed')

    def tickers(self):
        return self._get(ROOT+'/all-pairs/ticker',{'exchange':'EXCHANGE_2'})['data']
    def ticker(self,symbol):
        data=self._get(ROOT+'/ticker',{'exchange':'EXCHANGE_2','symbol':symbol})['data']
        if not isinstance(data,dict) or 'EXCHANGE_2' not in data:
            raise ValueError('Unexpected single-ticker data format')
        return data['EXCHANGE_2']
    def instruments(self):
        return self._get(ROOT+'/instrument_info',{'exchange':'EXCHANGE_2'})['data']
    def candles(self,symbol,interval,limit):
        # Cache by candle slot so 1m ticker polling doesn't repeatedly re-fetch
        # unchanged 5m/15m/60m closed-candle history.
        slot=int(time.time()//(int(interval)*60))
        key=(symbol,int(interval),int(limit),slot)
        if key not in self._klines_cache:
            obj=self._get(ROOT+'/klines',{'exchange':'EXCHANGE_2','symbol':symbol,
                         'interval':str(interval),'limit':str(limit)},kline=True)
            # Cache only successful full responses. On slot change re-fetch.
            self._klines_cache[key]=obj
            if len(self._klines_cache)>1000:
                self._klines_cache={k:v for k,v in self._klines_cache.items()
                    if k[3]>=int(time.time()//(k[1]*60))-1}
        return self._klines_cache[key]

    def kline_call_needed(self,symbol,interval,limit):
        slot=int(time.time()//(int(interval)*60))
        return (symbol,int(interval),int(limit),slot) not in self._klines_cache

    def kline_budget_available(self,symbol,interval,limit,round_count,round_max):
        # All API keys share the published 30 KLines requests / 60 seconds.
        now=time.monotonic()
        while self.kline_calls and now-self.kline_calls[0]>=61:
            self.kline_calls.popleft()
        return (not self.kline_call_needed(symbol,interval,limit) or
                (round_count<round_max and len(self.kline_calls)<27))

    def order_book(self,symbol):
        return self._get(ROOT+'/order_book',{'exchange':'EXCHANGE_2','symbol':symbol})['data']
