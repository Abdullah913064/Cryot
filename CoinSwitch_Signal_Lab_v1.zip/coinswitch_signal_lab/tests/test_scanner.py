import unittest
from scanner.indicators import Candle,ema,rsi,atr,dmi,cleaned_candles
from scanner.strategy import round_down_quantity,finalize,technical_candidate
from scanner.config import Config
from scanner.replay import wilson,evaluate
from scanner.main import clean_universe,rotate

class TestScanner(unittest.TestCase):
    def test_ema(self):
        result=ema([1,2,3,4,5],3)
        self.assertEqual(result[:2],[None,None]);self.assertAlmostEqual(result[-1],4)
    def test_rsi(self):
        result=rsi(list(range(1,30)))
        self.assertAlmostEqual(result[-1],100)
    def test_atr(self):
        c=[Candle(i*300000,(i+1)*300000,10,11,9,10,100) for i in range(40)]
        self.assertAlmostEqual(atr(c)[-1],2)
        p,m,a=dmi(c)
        self.assertIsNotNone(a[-1]);self.assertEqual(p[-1],0)
    def test_unfinished_bar_rejected(self):
        now=900000
        rows={'data':[{'start_time':0,'close_time':300000,'o':1,'h':2,'l':0.5,'c':1.3,'volume':10},
                      {'start_time':600000,'close_time':900000,'o':1,'h':2,'l':0.5,'c':1.3,'volume':10}]}
        parsed=cleaned_candles(rows,now,5)
        self.assertEqual(len(parsed),1)
    def test_lot_rounding(self):
        self.assertEqual(round_down_quantity(2.999,0.1),2.9)
        self.assertEqual(round_down_quantity(0.0008,0.001),0)
    def test_risk_cap_and_fees(self):
        cfg=Config(usdt_inr=100)
        meta={'max_leverage':'25','min_leverage':'1','taker_fee_rate':'0.00065',
              'base_quantity_step_size':'0.01','min_base_quantity':'0.01'}
        t={'last_price':'10','best_ask_price':'10.01','best_bid_price':'10'}
        x={'trigger':10,'dist':0.2,'stop':9.8,'side':'LONG','pattern':'Trend pullback',
           'score':7,'candle_time':1000,'atr':0.1,'recent_close':10}
        setup,reason=finalize('TESTUSDT',t,meta,x,cfg,spread=0.001)
        # Cost 0.8%, stop 2%; 3.4R target > net 2R, but ATR target may be too far.
        self.assertIsNone(setup)
        self.assertIn('target too far',reason)
        x['atr']=0.3
        setup,reason=finalize('TESTUSDT',t,meta,x,cfg,spread=0.001)
        self.assertIsNotNone(setup,reason)
        self.assertLessEqual(setup.planned_loss_inr,6.88)
        self.assertLessEqual(setup.approx_margin_inr,688*.30)
    def test_conservative_replay(self):
        bars=[Candle(0,300000,10,12,8,10,100)]
        trade=evaluate(bars,10.5,9.5,'LONG',0.008)
        self.assertEqual(trade['status'],'STOP')
        self.assertLess(trade['R'],0)
        self.assertIsNone(evaluate([Candle(0,300000,10,10.2,9.8,10,10)],10.5,9.5,'LONG',0.008))
        self.assertEqual(wilson(0,0),(None,None))
    def test_universe_stale_filter(self):
        now=1000000
        d={'AAUSDT':{'timestamp':now,'last_price':'5','best_bid_price':'4.999',
          'best_ask_price':'5.001','quote_asset_volume_24h':'2000000',
          'open_interest_value':'500000','funding_rate':0.0001},
          'BBUSDT':{'timestamp':1,'last_price':'5','best_bid_price':'4.999',
          'best_ask_price':'5.001','quote_asset_volume_24h':'2000000',
          'open_interest_value':'500000','funding_rate':0}}
        m={'AAUSDT':{'status':'TRADING'},'BBUSDT':{'status':'TRADING'}}
        self.assertEqual(clean_universe(d,m,Config(),now),['AAUSDT'])
        self.assertEqual(len(rotate(['A','B','C'],Config(max_symbols=2,core_symbols=1),now)),2)

if __name__=='__main__':unittest.main()
