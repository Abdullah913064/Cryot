# CoinSwitch Signal Lab — read-only futures scanner

> **Prototype, not a verified profitable system.** No orders are ever placed. No one can truthfully promise a high future win rate, especially with a ₹688 account. This app intentionally favors **NO TRADE** over a low-quality trade.

## What you get

- CoinSwitch PRO **Futures v2** integration using its documented **signed Ed25519** API, no trading endpoint calls.
- Retrieves **all-pairs 24h ticker**, **instrument rules**, completed 1h, 15m, 5m candles, and checks the order book before any alert.
- Screens only active contracts with sufficient volume, open interest and tight spreads. Picks the **five most liquid plus a rotating group**, default 12 symbols per scheduled run. It **does not scan every coin on each run**, due to API rate limits.
- Two candidate patterns: **trend pullback continuation** and **breakout + retest**. Both require 1h direction, 15m confirmation, 5m trigger and BTC alignment for altcoins.
- Checks 14-period RSI, DMI/ADX, ATR, EMA9/21/200, candle volume; rejects overextended entries and nearby structural barriers.
- Includes **observed fee floor 0.30% on each side** from previous CoinSwitch executions, plus configurable slippage and actual bid/ask spread; checks minimum contract quantity and projected ₹ risk before alerting.
- Generates a mobile-friendly **report.html** and (optionally) sends **Telegram** alerts.
- Contains an **offline technical backtest/replay** tool that deliberately refuses to publish a win probability from too few held-out trades.

### Signal meanings

A **LONG/SHORT alert** means a conditional trigger was detected on fully closed bars. It does **not** mean an order is placed, already filled, or guaranteed profitable. Alerts expire after the **next two 5-minute bars**. Always recheck the live market, latest candle, exchange rules and liquidation price before manually trading.

### Capital rules (configurable)

Starting reference balance **₹688**, planned maximum **1% = ₹6.88** per trade, **2×** modeled leverage, max **30%** of balance tied up as initial margin, required estimated net reward/risk **at least 2:1**. These calculations cannot guarantee loss limits because stops can slip or fail in fast markets. Never use all ₹688 as margin. Actual user/account fee schedule and current USDT/INR rate must be verified.

**USDT_INR is deliberately REQUIRED rather than guessing the FX conversion.** Set to the current INR value of 1 USDT displayed by the relevant exchange, and keep it updated. Without it, the scanner refuses real signals because position size could be wrong.

## Android-friendly setup — run automatically with GitHub Actions

You need a GitHub account, Telegram (if you want phone alerts), and a CoinSwitch PRO account that supports API Trading. You do **not** need to leave your phone running once GitHub Actions is configured.

1. Create a **private** GitHub repository. Upload/extract the contents of this ZIP to the **repository root**, including the hidden `.github/workflows/scan.yml` file. Easiest from a computer, or through GitHub's browser uploader. The ZIP is not directly a GitHub Actions workflow until its files are extracted.
2. In CoinSwitch PRO, visit **Profile → API Trading** and generate a key pair. Store the secret securely. If permissions are offered, grant **read-only** access, and **never** enable withdrawals or automatic trade execution. The *code* makes only GET requests. CoinSwitch may provide a key with broader permissions than the code needs, so treat it as highly sensitive.
3. In your repository, go to **Settings → Secrets and variables → Actions → New repository secret**. Create **`COINSWITCH_API_KEY`** and **`COINSWITCH_SECRET_KEY`**. Do not paste these in ChatGPT, issue comments, screenshots, or tracked files. If you don't want to use keys, the ZIP supports offline demo only.
4. Create a Telegram bot through **@BotFather**. In Telegram, open your bot, tap START and send `hello`. Save the bot token as repository secret **`TELEGRAM_BOT_TOKEN`**. To find your numeric chat ID without a computer, run the **Telegram Chat ID Setup** workflow manually from the GitHub Actions tab (after saving the token secret), and read its log; save the result as secret **`TELEGRAM_CHAT_ID`**. Alternatively run `python -m scanner.get_chat_id` locally. Do not post bot tokens online. Telegram is optional; without it, review the generated report artifact.
5. In **Settings → Secrets and variables → Actions → Variables**, add **`USDT_INR`** with your freshly verified quote (e.g., only if the live value actually is `NN.NN`). Add **`BALANCE_INR`** as `688` and **`OBSERVED_TAKER_FEE`** as `0.003`. Update when your balance or account fee changes. No INR conversion is inferred automatically.
6. Go to the **Actions** tab, enable workflows if prompted, select **CoinSwitch Read-only Scanner** and choose **Run workflow**. Check the log. At the bottom of the run, download the report artifact; open `report.html` in your browser. When strong conditional setups exist, Telegram will also get a concise alert.
7. The scheduled workflow attempts to run every **15 minutes** (UTC minutes 03,18,33,48). **GitHub does not guarantee exact timing**; runs can be delayed, skipped, paused, or disabled for inactive repositories. This is not suitable for high-frequency execution or tight real-time stop management.

**Verify the authentication and shape of the exchange responses on first run.** This prototype was built from CoinSwitch's developer documentation; its authenticated live calls have **not** been tested here with your account keys. If API returns errors, the app writes an error report and sends **no** trading signal.

## Optional local run on PC

Python 3.11 recommended:

```bash
python -m venv .venv
# Activate the venv (Windows: .venv\Scripts\activate ; Linux/Mac: source .venv/bin/activate)
pip install -r requirements.txt
python -m scanner.main --demo
```

Open `report.html`. It is labeled **OFFLINE DEMONSTRATION** and contains **no fabricated market signals**.

For live use, set `COINSWITCH_API_KEY`, `COINSWITCH_SECRET_KEY`, `USDT_INR` and optional `TELEGRAM_BOT_TOKEN`/`TELEGRAM_CHAT_ID` **in your environment**, not in code. Then run:

```bash
python -m scanner.main --no-telegram  # review report.html before enabling alerts
python -m scanner.main                # sends Telegram only on qualifying signals
```

Windows PowerShell example: `$env:BALANCE_INR='688'`. Linux/Mac example: `export BALANCE_INR=688`.

### Why not every pair every 5 minutes?

CoinSwitch's KLines REST endpoint allows **30 requests per 60 seconds**. Scanning 500 futures symbols across 3 timeframes = at least 1,500 KLines calls, excluding tickers/order books, far beyond a 5-minute REST scan. This first version uses all-pairs ticker filtering and a rotating liquid shortlist; a full-scale system would maintain persistent Socket.IO candle streams, a historical database, retry/reconnect logic, and a hosted process, with additional testing and operational cost.

## Download historical data from CoinSwitch (optional)

With your CoinSwitch API credentials stored locally, the included downloader can request consecutive 240-candle history windows while observing the documented KLines rate limit. Example:

```bash
python -m scanner.download --symbol LITUSDT --days 40
python -m scanner.replay --one-hour data/LITUSDT_60m.csv --fifteen-minute data/LITUSDT_15m.csv --five-minute data/LITUSDT_5m.csv
```

CoinSwitch may limit historical retention or range requests. Validate downloaded candle counts, gaps and timestamps before trusting a replay; a short or incomplete series cannot establish an edge. This may require many minutes and is separate from the scheduled signal scanner.

## Historical replay: don't confuse backtested frequency with a promise

The optional replay uses **the same technical setup** and conservative stop-first bar simulation, but it **cannot** reproduce past account-specific fees, order books, mark price, funding, gaps, partial fills or liquidation. Do not use replay results as a guarantee or calibrated real-money probability. It divides the completed trades by chronology: initial 70% development segment, final 30% held-out segment. A 95% Wilson interval is displayed only if there are **at least 50** held-out trades; even then it describes uncertainty **in the past sample**, not what future prices will do. Do not tune parameters against the held-out set and claim it is still independent.

Export 5-minute, 15-minute and 1-hour historical OHLCV into three CSVs (one market only). Headers:

```
start_ms,close_ms,open,high,low,close,volume
```

All timestamps are **Unix milliseconds UTC**; candles must be **fully closed**, ordered, and use their actual source exchange. Provide substantial history (1h >=250, 15m >=250, 5m >=2000). Run:

```bash
python -m scanner.replay --one-hour data/coin_1h.csv --fifteen-minute data/coin_15m.csv --five-minute data/coin_5m.csv --roundtrip-cost-pct 0.8
```

The output `replay_trades.csv` contains simulated fills and realized R; inspect losses, positive outcome frequency, expectancy, total trades, sample size and stability across changing regimes. For a defensible full-system win probability, capture actual historical ticker/order-book data and validate true out-of-sample execution over many trades.

## Safety and quality gates

- All market-data requests are `GET` and signed locally; there are **no place-order methods** in this repository.
- CoinSwitch's documented historical candle format uses `start_time`, `close_time`, `o`, `h`, `l`, `c`, `volume`; the program drops incomplete candles.
- Rejects stale market snapshots, crossed/wide spreads, low turnover, low open interest, unusual funding, misaligned trend, chasing, missing indicators, unreasonably wide stops, poor estimated R:R and oversized minimum orders.
- Considers instrument quantity step, minimum quantity, liquidation fee information and modeled leverage; **does not compute actual liquidation buffer** because that depends on current margin tier and execution details. Check it manually.
- No assumed or fabricated win percentage: score out of 10 is **only signal alignment**, not success likelihood.
- No automatic execution, no futures wallet reads, no scraping of your account.
- No alerts if missing account FX conversion or market access; diagnostic report is generated instead.

## Official documentation used

- CoinSwitch Futures KLines: https://api-trading.coinswitch.co/futures/reference/klines
- All-Pairs Ticker: https://api-trading.coinswitch.co/futures/reference/get-all-pairs-ticker
- Instrument Info: https://api-trading.coinswitch.co/futures/reference/get-instrument-info
- Order Book: https://api-trading.coinswitch.co/futures/reference/get-order-book
- API Authentication: https://api-trading.coinswitch.co/get-started/authentication
- Create API key: https://api-trading.coinswitch.co/get-started/generate-api-keys

## Next production upgrades

1. Persistent Socket.IO stream, heartbeat and reconnect, tick-level staleness checks, 5-minute bar close aggregation and market-universe tracking.
2. Archived OHLCV + order-book/funding snapshots in a database, properly walk-forward backtested with transaction costs.
3. A hosted phone-friendly live dashboard and alerts with time-to-expiry and deduplication.
4. Actual broker fee and current USDT/INR read-only sync, plus automated shutdown on unusually wide spread or API outages.

**This scanner is software for evaluating trade setups, not a financial advisor, broker, automated order service, or guarantee of returns.**
