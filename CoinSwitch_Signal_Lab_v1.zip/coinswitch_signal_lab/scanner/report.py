import html
import json
from datetime import datetime,timezone
from pathlib import Path

CSS='''
:root{color-scheme:dark}*{box-sizing:border-box}body{background:#090e17;color:#ecf2f8;font:15px/1.6 system-ui,-apple-system,Segoe UI,sans-serif;max-width:1060px;margin:auto;padding:34px 20px}h1{font-size:clamp(26px,4vw,42px);line-height:1.15;letter-spacing:-.03em;margin:0 0 4px}h2{font-size:21px}.muted{color:#9ca9ba}.kicker{color:#4fe0bd;font-weight:700;letter-spacing:.1em;text-transform:uppercase;font-size:12px}.hero{background:linear-gradient(135deg,#172739,#0d1625);padding:28px;border:1px solid #2c4055;border-radius:22px;margin:20px 0}.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px}.stat,.tile{background:#111a28;border:1px solid #2b3a4e;border-radius:14px;padding:16px}.stat b{font-size:26px;display:block}.tile{margin:15px 0}.tile h3{font-size:19px;margin:0}.tag{display:inline-block;font-size:12px;font-weight:700;border-radius:20px;padding:5px 11px;background:#203a3b;color:#7cf3d3}.warn{background:#453b25;color:#ffe3a3}.danger{background:#3d2935;color:#ff9da8}table{border-collapse:collapse;width:100%;margin-top:12px}td{border-top:1px solid #28364a;padding:9px 6px}td:nth-child(even){text-align:right;font-variant-numeric:tabular-nums}code{color:#83dac6}.foot{color:#97a7b8;font-size:13px;margin-top:25px}a{color:#80c6ef}@media(max-width:600px){body{padding:15px}.hero{padding:18px}.stat b{font-size:21px}}
'''

def write_report(path, signals,stats,config,errors, live):
    at=datetime.now(timezone.utc).strftime('%d %b %Y %H:%M UTC')
    cards=[]
    for s in signals:
        color='tag' if s.side=='LONG' else 'tag danger'
        vals=[('Entry trigger (not filled)',f'{s.trigger:.8g}'),('Protective stop',f'{s.stop:.8g}'),
              ('Target 1',f'{s.target1:.8g}'),('Target 2',f'{s.target2:.8g}'),
              ('Estimated net reward:risk',f'{s.net_rr:.2f}:1'),('Signal quality',f'{s.score}/10 (not a win %)'),
              ('Qty (base coins)',f'{s.qty:g}'),('Est. margin INR',f'₹{s.approx_margin_inr:.2f}'),
              ('Planned loss INR',f'₹{s.planned_loss_inr:.2f}'),('Round-trip cost allowance',f'{s.estimated_cost_pct:.2f}%')]
        rows=''.join(f'<tr><td>{html.escape(a)}</td><td>{html.escape(b)}</td></tr>' for a,b in vals)
        cards.append(f'<article class="tile"><span class="{color}">{s.side}</span> <span class="muted">{html.escape(s.pattern)}</span><h3>{html.escape(s.symbol)}</h3><table>{rows}</table><p class="muted">{html.escape(s.notes)}</p></article>')
    body=''.join(cards) if cards else '<article class="tile"><span class="tag warn">NO SIGNAL</span><h3>No setup passed every safety filter</h3><p>This is a valid outcome. No trade is often the best decision.</p></article>'
    err=''.join(f'<p class="muted">• {html.escape(str(e))}</p>' for e in errors[:12])
    stamp='LIVE API RESULTS' if live else 'OFFLINE DEMONSTRATION ONLY — NO MARKET DATA'
    page=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Signal Lab | CoinSwitch</title><style>{CSS}</style></head><body>
    <p class="kicker">Signal Lab • CoinSwitch Futures</p><h1>Trade less.<br>Filter harder.</h1><p class="muted">{html.escape(stamp)} • generated {at}</p>
    <section class="hero"><span class="tag warn">ALERT-ONLY / NO AUTO-TRADING</span><h2>Market scan report</h2><div class="stats">
      <div class="stat">All-pairs <b>{stats.get('universe',0)}</b></div>
      <div class="stat">Eligible <b>{stats.get('eligible',0)}</b></div>
      <div class="stat">Analyzed <b>{stats.get('scanned',0)}</b></div>
      <div class="stat">Signals <b>{len(signals)}</b></div>
    </div></section>
    <h2>Conditional opportunities</h2>{body}<section class="tile"><h3>Capital protection</h3><p>Account reference <b>₹{config.balance_inr:.2f}</b>; standard risk ceiling <b>₹{config.balance_inr*config.risk_fraction:.2f}</b> per hypothetical trade. Margin capped at {config.margin_fraction:.0%} of the reference balance. Maximum configured leverage {config.leverage:g}×.</p><p class="muted">Quality 0–10 is a rules-based ranking, NOT a statistically measured win chance. Until properly out-of-sample tested, winning probability is unknown.</p></section>
    <h2>Skipped / diagnostic messages</h2>{err or '<p class="muted">No diagnostic messages.</p>'}
    <p class="foot">The report is informational. No order is sent. Confirm the current exchange price, fees, instrument size, order book, stop order functionality and funding yourself. Triggers expire after two 5m candles. Sudden price movement can bypass stops. Crypto futures can cause significant losses.</p></body></html>'''
    Path(path).write_text(page,encoding='utf-8')
