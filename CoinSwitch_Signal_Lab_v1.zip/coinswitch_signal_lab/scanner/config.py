from dataclasses import dataclass
import os

@dataclass
class Config:
    balance_inr:float=688.0
    risk_fraction:float=0.01
    daily_loss_limit_fraction:float=0.03
    leverage:float=2.0
    margin_fraction:float=0.30
    usdt_inr:float=0.0
    min_turnover_usdt:float=1000000.0
    min_oi_usdt:float=100000.0
    max_spread:float=0.0012
    max_funding:float=0.003
    # User's observed taker fills were about 0.30% each way. Conservative floor until verified.
    observed_taker_fee:float=0.003
    slippage_each_side:float=0.0005
    max_symbols:int=12
    core_symbols:int=5
    min_net_rr:float=2.0
    max_ticker_age_sec:float=180

    @staticmethod
    def from_env():
        def number(k,d):
            value=os.getenv(k,'').strip()
            return type(d)(value) if value else d
        c=Config()
        for key in ('balance_inr','risk_fraction','leverage','margin_fraction','usdt_inr',
                    'min_turnover_usdt','min_oi_usdt','max_spread','max_funding',
                    'observed_taker_fee','slippage_each_side','max_symbols','core_symbols','min_net_rr'):
            setattr(c,key,number(key.upper(),getattr(c,key)))
        assert c.balance_inr>0 and 0<c.risk_fraction<=0.02 and 1<=c.leverage<=3
        assert 0<c.margin_fraction<=0.4 and c.max_symbols>=1
        return c
