"""CoinSwitch Futures Signal Lab — informational, read-only."""
