"""Conservative, symmetric trend-continuation setup rules.

All inputs end at CLOSED candles. Entries are CONDITIONAL break triggers, not executed trades.
"""
from dataclasses import dataclass,asdict
from decimal import Decimal,ROUND_FLOOR
from scanner.indicators import features

@dataclass
class Setup:
    symbol:str
    side:str
    pattern:str
    score:int
    timestamp:int
    last_price:float
    trigger:float
    stop:float
    target1:float
    target2:float
    net_rr:float
    spread_pct:float
    estimated_cost_pct:float
    qty:float
    approx_margin_inr:float
    planned_loss_inr:float
    risk_inr:float
    notes:str

    def as_dict(self): return asdict(self)


def trend_side(bars, f):
    if len(bars)<220 or any(f[k][-1] is None for k in ('ema21','ema200','rsi','adx','plus_di','minus_di')):
        return None
    c=bars[-1].c; e21=f['ema21'][-1]; e200=f['ema200'][-1]
    if c>e21>e200 and f['rsi'][-1]>50 and f['plus_di'][-1]>f['minus_di'][-1] and f['adx'][-1]>=19:
        return 'LONG'
    if c<e21<e200 and f['rsi'][-1]<50 and f['minus_di'][-1]>f['plus_di'][-1] and f['adx'][-1]>=19:
        return 'SHORT'
    return None


def technical_candidate(b1,b15,b5):
    """Returns setup dict or reason. Used identically by live scan and optional backtest."""
    if len(b1)<220 or len(b15)<65 or len(b5)<50:
        return None,'Not enough historical closed candles'
    f1=features(b1); f15=features(b15); f5=features(b5)
    side=trend_side(b1,f1)
    if not side: return None,'1h trend not aligned'
    long=side=='LONG'
    i=-1; last=b15[-1]; prev=b15[-2]; last5=b5[-1]
    e9=f15['ema9'][-1]; e21=f15['ema21'][-1]
    at=f15['atr'][-1]; a5=f5['atr'][-1]
    if not all(x is not None and x>0 for x in (e9,e21,at,a5)):
        return None,'Insufficient indicator history'
    r=f15['rsi'][-1]; ad=f15['adx'][-1]
    if not all(v is not None for v in (r,ad,f15['volume_ma20'][-1])):
        return None,'Insufficient DMI / volume'
    if long:
        if not (e9>e21 and 51<=r<=70 and f15['plus_di'][-1]>f15['minus_di'][-1] and ad>=21):
            return None,'15m bullish momentum not aligned'
    else:
        if not (e9<e21 and 30<=r<=49 and f15['minus_di'][-1]>f15['plus_di'][-1] and ad>=21):
            return None,'15m bearish momentum not aligned'
    if abs(last.c-e21)>1.6*at:
        return None,'Price too extended from 15m EMA21'
    vol_ratio=last.v/max(f15['volume_ma20'][-1],1e-12)
    touched=any((b.l<=f15['ema21'][j]+0.35*at if long else b.h>=f15['ema21'][j]-0.35*at)
                for j,b in zip(range(len(b15)-4,len(b15)-1),b15[-4:-1]))
    continuation=(touched and vol_ratio>=1.10 and
                  ((long and last.c>e9 and last.c>last.o and last.c>prev.c)
                   or (not long and last.c<e9 and last.c<last.o and last.c<prev.c)))
    # Previous bar broke the 20-bar range; latest bar retested it without closing back inside.
    prior=b15[-22:-2]
    if len(prior)<20: return None,'Insufficient range'
    level=max(x.h for x in prior) if long else min(x.l for x in prior)
    broke=(b15[-2].c>level if long else b15[-2].c<level)
    retested=(last.l<=level+0.35*at and last.c>level if long
              else last.h>=level-0.35*at and last.c<level)
    breakout=broke and retested and vol_ratio>=0.95 and (last.c>last.o if long else last.c<last.o)
    if not continuation and not breakout:
        return None,'No confirmed 15m pullback/retest pattern'
    # 5m entry timing confirmation.
    fast=f5['ema9'][-1]; slow=f5['ema21'][-1]; r5=f5['rsi'][-1]
    if None in (fast,slow,r5) or f5['volume_ma20'][-1] is None:
        return None,'5m history too short'
    if long:
        if not(fast>slow and 50<=r5<=72 and last5.c>fast and last5.c>=last5.o):
            return None,'5m bullish confirmation absent'
    else:
        if not(fast<slow and 28<=r5<=50 and last5.c<fast and last5.c<=last5.o):
            return None,'5m bearish confirmation absent'
    # Only trigger during NEXT two 5m bars. No automatic fill.
    trigger=last5.h+last5.c*0.0002 if long else last5.l-last5.c*0.0002
    recent=b5[-5:]
    stop=(min(c.l for c in recent)-0.15*a5 if long
          else max(c.h for c in recent)+0.15*a5)
    dist=(trigger-stop) if long else (stop-trigger)
    if dist<=0 or not (0.35*at<=dist<=2.6*at):
        return None,'Stop distance outside volatility range'
    # Reject targets blocked by obvious nearby unbroken swing levels.
    past=b15[-85:-3]
    obstructions=[b.h for b in past if b.h>trigger] if long else [b.l for b in past if b.l<trigger]
    nearest=(min(obstructions) if long else max(obstructions)) if obstructions else None
    if nearest is not None and abs(nearest-trigger)<3.4*dist:
        return None,'Nearest structural resistance/support too close'
    score=min(10,5 + int(ad>=30) + int(vol_ratio>=1.4) + int(f1['adx'][-1]>=30) + int(breakout))
    return dict(side=side,pattern='Breakout retest' if breakout else 'Trend pullback',
                trigger=trigger, stop=stop, dist=dist, score=score, atr=at,
                candle_time=b5[-1].close_ms, recent_close=last5.c,
                volume_ratio=vol_ratio),''


def round_down_quantity(qty,step):
    step=Decimal(str(step))
    if step<=0: return 0.0
    q=Decimal(str(qty))
    return float((q/step).to_integral_value(rounding=ROUND_FLOOR)*step)


def finalize(symbol,ticker,meta,technical,config,spread=None):
    """Reject unsafe setups; size only if an explicit INR/USDT conversion is supplied."""
    if config.usdt_inr<=0: return None,'USDT_INR conversion not set; cannot safely size INR account'
    px=technical['trigger']; dist=technical['dist']; side=technical['side']
    last=float(ticker['last_price'])
    if abs(last-px)/px>0.012: return None,'Price moved away from entry trigger'
    spread=float(spread if spread is not None else (float(ticker['best_ask_price'])-float(ticker['best_bid_price']))/last)
    if spread<0 or spread>config.max_spread: return None,'Unsafe or crossed spread'
    if config.leverage>float(meta.get('max_leverage',1)):
        return None,'Requested leverage exceeds instrument limit'
    if config.leverage<float(meta.get('min_leverage',1)):
        return None,'Leverage below contract minimum'
    fee=max(float(meta.get('taker_fee_rate',0)),config.observed_taker_fee)
    costs=2*(fee+config.slippage_each_side)+spread
    risk_ratio=dist/px+costs
    if risk_ratio<=0: return None,'Invalid risk'
    budget=config.balance_inr*config.risk_fraction
    nominal_usdt=min(budget/(risk_ratio*config.usdt_inr),
                     (config.balance_inr*config.margin_fraction*config.leverage)/config.usdt_inr)
    quantity=round_down_quantity(nominal_usdt/px,meta.get('base_quantity_step_size','0'))
    if quantity<=0 or quantity<float(meta.get('min_base_quantity',0)):
        return None,'Minimum trade quantity not affordable within safe risk/margin'
    if quantity>float(meta.get('max_market_base_quantity',1e18)):
        return None,'Quantity exceeds contract limit'
    estimated_loss=quantity*px*config.usdt_inr*risk_ratio
    if estimated_loss>budget+0.01: return None,'Risk budget exceeded'
    margin=quantity*px*config.usdt_inr/config.leverage
    if margin>config.balance_inr*config.margin_fraction+0.01:
        return None,'Margin exceeds account allocation'
    direction=1 if side=='LONG' else -1
    # Target 2 is a hypothetical extension; requires manual support/resistance review.
    first=px+direction*1.8*dist
    second=px+direction*3.4*dist
    net_rr=(abs(second-px)/px-costs)/risk_ratio
    if net_rr<config.min_net_rr: return None,'Net reward/risk below minimum'
    # Filter targets that require implausibly large move for this intraday setup.
    if abs(second-px)>4.5*technical['atr']:
        return None,'2R+ target too far relative to 15m volatility'
    return Setup(symbol,side,technical['pattern'],technical['score'],technical['candle_time'],last,
                 px,technical['stop'],first,second,round(net_rr,2),100*spread,100*costs,
                 quantity,round(margin,2),round(estimated_loss,2),round(budget,2),
                 'Conditional alert: entry trigger valid for next two 5m candles ONLY; validate target obstacles and live fees before placing any order.'),''
