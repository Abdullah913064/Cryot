"""Telegram notifications; no exchange trading permissions required."""
import json
import os
import requests


def send_telegram(message):
    token=os.getenv('TELEGRAM_BOT_TOKEN','').strip()
    chat=os.getenv('TELEGRAM_CHAT_ID','').strip()
    if not token or not chat:
        return False,'Telegram credentials not configured; console/HTML report available.'
    url=f'https://api.telegram.org/bot{token}/sendMessage'
    r=requests.post(url,json={'chat_id':chat,'text':message,'disable_web_page_preview':True},timeout=15)
    r.raise_for_status()
    if not r.json().get('ok'):
        raise RuntimeError('Telegram rejected alert')
    return True,'Telegram delivered'


def format_alert(setups,stats,config):
    lines=['📊 CoinSwitch Futures — CONDITIONAL WATCH','No trade is executed by this bot.',
           f"Verified candles: {stats.get('scanned',0)} pairs / {stats.get('eligible',0)} liquid eligible; all-pairs universe {stats.get('universe',0)}",
           f"Risk cap ₹{config.balance_inr*config.risk_fraction:.2f} | Balance reference ₹{config.balance_inr:.2f}"]
    for s in setups[:3]:
        lines += [f'\n{s.side} {s.symbol}  | {s.pattern} | Quality {s.score}/10',
                  f'Conditional trigger {s.trigger:.8g} | Stop {s.stop:.8g}',
                  f'Targets {s.target1:.8g} / {s.target2:.8g} | Net R:R ~{s.net_rr:.2f}:1',
                  f'Qty {s.qty:g} | Est. margin ₹{s.approx_margin_inr:.2f} | Planned risk ₹{s.planned_loss_inr:.2f}',
                  f'Estimated costs {s.estimated_cost_pct:.2f}% of notional; funding not included',
                  'EXPIRES after next two 5m bars; confirm live spread, slippage and liquidation buffer.']
    lines.append('WIN %: Not available—no out-of-sample validation. Futures can lose more than planned on gaps/slippage.')
    return '\n'.join(lines)
