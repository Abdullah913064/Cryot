"""READ-ONLY CoinSwitch futures API client. No order placement methods."""
import os
import time
from collections import deque
from urllib.parse import urlencode,unquote_plus
import requests
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

BASE='https://coinswitch.co'
ROOT='/trade/api/v2/futures'

class CoinSwitchClient:
    def __init__(self):
        self.key=os.getenv('COINSWITCH_API_KEY','').strip()
        self.secret=os.getenv('COINSWITCH_SECRET_KEY','').strip()
        if not self.key or not self.secret:
            raise ValueError('Set COINSWITCH_API_KEY and COINSWITCH_SECRET_KEY environment variables. Do not paste keys into chat.')
        if len(bytes.fromhex(self.secret))!=32:
            raise ValueError('CoinSwitch private key should be a 32-byte Ed25519 hex seed')
        self.private=Ed25519PrivateKey.from_private_bytes(bytes.fromhex(self.secret))
        self.http=requests.Session()
        self.kline_calls=deque()

    def _get(self,path,params=None,kline=False):
        if kline:
            # A rolling limiter with safety headroom: 28 of documented 30 / 60 sec.
            while True:
                now=time.monotonic()
                while self.kline_calls and now-self.kline_calls[0]>=61:
                    self.kline_calls.popleft()
                if len(self.kline_calls)<28:
                    self.kline_calls.append(now)
                    break
                time.sleep(min(2,max(.2,61-(now-self.kline_calls[0]))))
        raw=path+('?' + urlencode(params) if params else '')
        signed=unquote_plus(raw)
        for attempt in range(3):
            # Re-sign for each retry: API timestamps expire quickly.
            epoch=str(int(time.time()*1000))
            signature=self.private.sign(('GET'+signed+epoch).encode()).hex()
            headers={'Content-Type':'application/json','X-AUTH-APIKEY':self.key,
                     'X-AUTH-SIGNATURE':signature,'X-AUTH-EPOCH':epoch}
            try:
                r=self.http.get(BASE+raw,headers=headers,timeout=15)
                if r.status_code==429 and attempt<2:
                    time.sleep(5*(attempt+1));continue
                r.raise_for_status()
                obj=r.json()
                if not isinstance(obj,dict) or 'data' not in obj:
                    raise ValueError('Unexpected API response: '+str(obj)[:150])
                return obj
            except (requests.exceptions.Timeout,requests.exceptions.ConnectionError):
                if attempt==2:raise
                time.sleep(1+attempt*2)
        raise RuntimeError('Request failed')

    def tickers(self):
        return self._get(ROOT+'/all-pairs/ticker',{'exchange':'EXCHANGE_2'})['data']
    def ticker(self,symbol):
        data=self._get(ROOT+'/ticker',{'exchange':'EXCHANGE_2','symbol':symbol})['data']
        if not isinstance(data,dict) or 'EXCHANGE_2' not in data:
            raise ValueError('Unexpected single-ticker data format')
        return data['EXCHANGE_2']
    def instruments(self):
        return self._get(ROOT+'/instrument_info',{'exchange':'EXCHANGE_2'})['data']
    def candles(self,symbol,interval,limit):
        return self._get(ROOT+'/klines',{'exchange':'EXCHANGE_2','symbol':symbol,
                           'interval':str(interval),'limit':str(limit)},kline=True)
    def order_book(self,symbol):
        return self._get(ROOT+'/order_book',{'exchange':'EXCHANGE_2','symbol':symbol})['data']
