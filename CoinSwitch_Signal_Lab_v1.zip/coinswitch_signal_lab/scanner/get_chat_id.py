"""Find your chat ID after sending your newly created Telegram bot a hello message."""
import os
import requests

def main():
    token=os.getenv('TELEGRAM_BOT_TOKEN','').strip()
    if not token:raise SystemExit('Set TELEGRAM_BOT_TOKEN in your own environment first.')
    resp=requests.get(f'https://api.telegram.org/bot{token}/getUpdates',timeout=15)
    resp.raise_for_status()
    chats={}
    for item in resp.json().get('result',[]):
        m=item.get('message') or item.get('edited_message') or {}
        chat=m.get('chat',{})
        if 'id' in chat:chats[chat['id']]=chat.get('title') or chat.get('username') or chat.get('first_name') or ''
    if not chats:print('No chats yet. Open the bot in Telegram and press START, then send hello and run again.')
    for ident,name in chats.items():print('Chat ID:',ident,'Name:',name)

if __name__=='__main__':main()
