"""Market wide prefilter -> rotating multi-timeframe scan -> conditional Telegram alert.

Run: python -m scanner.main --demo OR python -m scanner.main
No account orders are ever placed.
"""
import argparse
from datetime import datetime,timezone
import json
import os
import time
from pathlib import Path
from scanner.client import CoinSwitchClient
from scanner.config import Config
from scanner.indicators import cleaned_candles,features
from scanner.strategy import technical_candidate,finalize,trend_side
from scanner.report import write_report
from scanner.notify import send_telegram,format_alert


def number(value,default=0):
    try: return float(value)
    except (ValueError,TypeError):return default


def clean_universe(tickers,instruments,cfg,now_ms):
    eligible=[]
    for sym,t in tickers.items():
        if not isinstance(t,dict) or sym not in instruments:continue
        m=instruments[sym]
        if m.get('status')!='TRADING':continue
        if not (now_ms-cfg.max_ticker_age_sec*1000 <= number(t.get('timestamp')) <= now_ms+10000):continue
        quote=number(t.get('quote_asset_volume_24h'))
        oi=number(t.get('open_interest_value'))
        if quote<cfg.min_turnover_usdt or oi<cfg.min_oi_usdt:continue
        px=number(t.get('last_price')); bid=number(t.get('best_bid_price')); ask=number(t.get('best_ask_price'))
        if px<=0 or bid<=0 or ask<=bid:continue
        spread=(ask-bid)/((ask+bid)/2)
        if spread>cfg.max_spread:continue
        if abs(number(t.get('funding_rate')))>cfg.max_funding:continue
        eligible.append((sym,quote))
    return [sym for sym,_ in sorted(eligible,key=lambda a:a[1],reverse=True)]


def rotate(eligible,cfg,now_ms):
    core=eligible[:min(cfg.core_symbols,cfg.max_symbols)]
    rest=eligible[len(core):]
    free=max(0,cfg.max_symbols-len(core))
    if not rest or free<=0:return core
    # Rotates non-core slice every 15 minutes. May take multiple runs to cover the universe.
    slot=now_ms//900000
    start=(slot*free)%len(rest)
    chosen=[rest[(start+i)%len(rest)] for i in range(min(free,len(rest)))]
    return core+chosen


def scan(cfg,client,now_ms):
    stats={'universe':0,'eligible':0,'scanned':0,'qualified':0,'timestamp':now_ms}
    diagnostics=[]; signals=[]
    tickers=client.tickers(); instruments=client.instruments()
    if not isinstance(tickers,dict) or not isinstance(instruments,dict):
        raise ValueError('CoinSwitch returned unexpected all-pairs metadata structure')
    stats['universe']=len(tickers)
    eligible=clean_universe(tickers,instruments,cfg,now_ms)
    stats['eligible']=len(eligible)
    targets=rotate(eligible,cfg,now_ms)
    # For safety, require BTC trend context. If unavailable we still report scan, but no alerts.
    try:
        btc=cleaned_candles(client.candles('BTCUSDT',60,260),now_ms,60)
        btc_side=trend_side(btc,features(btc))
    except Exception as e:
        btc_side=None
        diagnostics.append('BTC trend unavailable: '+str(e)[:130])
    for sym in targets:
        try:
            b1=cleaned_candles(client.candles(sym,60,260),now_ms,60)
            b15=cleaned_candles(client.candles(sym,15,160),now_ms,15)
            stats['scanned']+=1
            if len(b1)<220 or len(b15)<65:
                diagnostics.append(sym+': insufficient history');continue
            tside=trend_side(b1,features(b1))
            if tside is None:
                continue
            # Avoid risk-on alt LONGs against BTC downtrends, and shorts against BTC uptrend.
            if sym!='BTCUSDT' and btc_side!=tside:
                continue
            b5=cleaned_candles(client.candles(sym,5,110),now_ms,5)
            if not b5 or int(time.time()*1000)-b5[-1].close_ms>7*60*1000:
                diagnostics.append(sym+': stale 5m candles');continue
            technical,reason=technical_candidate(b1,b15,b5)
            if not technical:
                continue
            # Confirm order book is sane; reject crossed books or wider spreads.
            fresh=client.ticker(sym)
            fresh_ms=int(time.time()*1000)
            if not(fresh_ms-cfg.max_ticker_age_sec*1000 <= number(fresh.get('timestamp')) <= fresh_ms+10000):
                continue
            # Do not send an already-triggered stale entry alert.
            fresh_price=number(fresh.get('last_price'))
            if (technical['side']=='LONG' and fresh_price>=technical['trigger']) or (technical['side']=='SHORT' and fresh_price<=technical['trigger']):
                continue
            book=client.order_book(sym)
            if abs(fresh_ms-number(book.get('timestamp')))>cfg.max_ticker_age_sec*1000:
                continue
            bids=book.get('bids',[]);asks=book.get('asks',[])
            if not bids or not asks:continue
            bid=float(bids[0][0]);ask=float(asks[0][0]);mid=(bid+ask)/2
            if mid<=0 or ask<=bid:continue
            book_spread=(ask-bid)/mid
            if book_spread>cfg.max_spread:continue
            setup,reason=finalize(sym,fresh,instruments[sym],technical,cfg,book_spread)
            if setup:signals.append(setup)
            elif len(diagnostics)<15:diagnostics.append(sym+': '+reason)
        except Exception as e:
            diagnostics.append(sym+': '+str(e)[:130])
    signals.sort(key=lambda s:(s.score,s.net_rr),reverse=True)
    stats['qualified']=len(signals)
    return signals[:3],stats,diagnostics


def main():
    p=argparse.ArgumentParser(description='CoinSwitch Futures signal watch (read only)')
    p.add_argument('--demo',action='store_true',help='Generate an offline, clearly marked sample report without using the exchange')
    p.add_argument('--no-telegram',action='store_true')
    p.add_argument('--report',default='report.html')
    a=p.parse_args();cfg=Config.from_env()
    if a.demo:
        stats={'universe':0,'eligible':0,'scanned':0,'qualified':0}
        write_report(a.report,[],stats,cfg,['Demo mode: no CoinSwitch calls, no market signals.'],live=False)
        print('OFFLINE DEMO: '+a.report+' (no signals, no market data)')
        return
    if cfg.usdt_inr<=0:
        raise SystemExit('USDT_INR is required for INR position sizing. Check current conversion, then set USDT_INR before scanning.')
    client=CoinSwitchClient()
    now_ms=int(time.time()*1000)
    try: signals,stats,diag=scan(cfg,client,now_ms)
    except Exception as e:
        write_report(a.report,[],{'universe':0,'eligible':0,'scanned':0},cfg,
                     ['SCAN FAILED — no trustworthy signals: '+str(e)],live=False)
        raise SystemExit('Scan failed; NO ALERT SENT: '+str(e))
    write_report(a.report,signals,stats,cfg,diag,live=True)
    Path('last_scan.json').write_text(json.dumps({'signals':[s.as_dict() for s in signals],
        'stats':stats,'errors':diag},indent=2))
    print(f"Analyzed {stats['scanned']} / {stats['eligible']} eligible from {stats['universe']} tickers, found {len(signals)} conditional opportunities")
    for s in signals: print(s.side,s.symbol,'score',s.score,'net RR',s.net_rr)
    if signals and not a.no_telegram:
        ok,detail=send_telegram(format_alert(signals,stats,cfg))
        print(detail)
    print('Report: '+a.report)

if __name__=='__main__':main()
