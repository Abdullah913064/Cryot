"""Optional, offline historical replay of the technical entry rules.

IMPORTANT: This is a TECHNICAL replay, NOT a full exchange execution simulation.
It has no historic order books, funding, liquidation/margin events, or exact fills.
The output is not a forecast or a calibrated future win probability.
"""
import argparse
import bisect
import csv
import math
from pathlib import Path
from scanner.indicators import Candle
from scanner.strategy import technical_candidate


def read_csv(path,minutes):
    out=[]
    with open(path,newline='') as fh:
        for row in csv.DictReader(fh):
            start=int(row['start_ms'])
            close=int(row.get('close_ms') or start+60000*minutes)
            c=Candle(start,close,*[float(row[k]) for k in ('open','high','low','close','volume')])
            if min(c.o,c.h,c.l,c.c)<=0 or c.h<max(c.o,c.c) or c.l>min(c.o,c.c):
                raise ValueError('Malformed candle row')
            out.append(c)
    out.sort(key=lambda c:c.close_ms)
    if len(set(c.close_ms for c in out))!=len(out):raise ValueError('Duplicate candle timestamps')
    return out


def wilson(w,n,z=1.96):
    if not n: return None,None
    p=w/n;denom=1+z*z/n
    center=(p+z*z/(2*n))/denom
    half=z*math.sqrt((p*(1-p)+z*z/(4*n))/n)/denom
    return max(0,center-half),min(1,center+half)


def evaluate(c5,trigger,stop,side,fee_frac,horizon=36):
    """Buy/sell-stop trigger in NEXT TWO bars; conservative stop-first if ambiguous."""
    islong=side=='LONG';direction=1 if islong else -1
    dist=abs(trigger-stop)
    if dist<=0:return None
    target=trigger+direction*3.4*dist
    trigger_at=None
    for k in range(min(2,len(c5))):
        bar=c5[k]
        touched=bar.h>=trigger if islong else bar.l<=trigger
        if touched:
            trigger_at=k;break
    if trigger_at is None:return None
    last=min(len(c5),trigger_at+horizon)
    if last<=trigger_at:return None
    status='HORIZON';exitprice=c5[last-1].c
    for k in range(trigger_at,last):
        bar=c5[k]
        stop_hit=bar.l<=stop if islong else bar.h>=stop
        target_hit=bar.h>=target if islong else bar.l<=target
        if stop_hit: exitprice=stop;status='STOP';break   # Conservative intrabar ordering
        if target_hit:exitprice=target;status='TARGET';break
    pnl_frac=(exitprice-trigger)/trigger*direction-fee_frac
    risk_frac=dist/trigger+fee_frac
    return dict(entry=trigger,stop=stop,target=target,exit=exitprice,
                status=status,pnl_fraction=pnl_frac,R=pnl_frac/risk_frac)


def replay(b1,b15,b5,fee_frac=0.008):
    if len(b1)<250 or len(b15)<250 or len(b5)<2000:
        raise ValueError('Replay needs substantial contiguous history: 1h >=250, 15m >=250, 5m >=2000 candles.')
    t1=[c.close_ms for c in b1];t15=[c.close_ms for c in b15]
    deals=[];busy_until=0
    for i in range(1800,len(b5)-40):
        # Evaluate only exactly when a 15m bar closes. No incomplete candles.
        when=b5[i].close_ms
        k15=bisect.bisect_right(t15,when)
        k1=bisect.bisect_right(t1,when)
        if k15<3 or t15[k15-1]!=when or k1<220 or when<=busy_until:continue
        x,reason=technical_candidate(b1[max(0,k1-260):k1],b15[max(0,k15-150):k15],b5[i-85:i+1])
        if x is None:continue
        test=evaluate(b5[i+1:i+40],x['trigger'],x['stop'],x['side'],fee_frac)
        if test is None:continue
        test.update(timestamp=when,side=x['side'],pattern=x['pattern'],score=x['score'])
        deals.append(test)
        busy_until=when+36*5*60000
    return deals


def summary(deals):
    if not deals:return dict(count=0,message='No completed simulated trades; probability unavailable')
    n=len(deals); wins=sum(x['pnl_fraction']>0 for x in deals)
    target=sum(x['status']=='TARGET' for x in deals)
    split=int(n*0.7); test=deals[split:]
    ntest=len(test); wins_test=sum(x['pnl_fraction']>0 for x in test)
    lo,hi=wilson(wins_test,ntest)
    result={'count':n,'positive_trades':wins,'historical_positive_pct':round(100*wins/n,1),
            'target_hits':target,'mean_R':round(sum(x['R'] for x in deals)/n,3),
            'out_of_sample_count':ntest,'out_of_sample_wins':wins_test,
            'out_of_sample_mean_R':round(sum(x['R'] for x in test)/ntest,3) if ntest else None,
            'oos_win_pct':round(100*wins_test/ntest,1) if ntest else None}
    if ntest>=50:
        result['oos_wilson_95_pct']=[round(100*lo,1),round(100*hi,1)]
    else:
        result['oos_wilson_95_pct']='INSUFFICIENT SAMPLE (<50 out-of-sample trades)'
    return result


def main():
    p=argparse.ArgumentParser(description='Technical replay (no historical order books/funding)')
    p.add_argument('--one-hour',required=True)
    p.add_argument('--fifteen-minute',required=True)
    p.add_argument('--five-minute',required=True)
    p.add_argument('--roundtrip-cost-pct',type=float,default=0.8,
                   help='Fees + slippage + spread in percent of notional, default 0.8')
    p.add_argument('--output',default='replay_trades.csv')
    a=p.parse_args()
    if a.roundtrip_cost_pct<0:raise SystemExit('Cost must be nonnegative')
    deals=replay(read_csv(a.one_hour,60),read_csv(a.fifteen_minute,15),
                 read_csv(a.five_minute,5),a.roundtrip_cost_pct/100)
    if deals:
        with open(a.output,'w',newline='') as fh:
            w=csv.DictWriter(fh,fieldnames=deals[0].keys());w.writeheader();w.writerows(deals)
    print('Technical-only historical replay; no historic spread/liquidity/funding/fill simulation.')
    print('Chronological final 30% held out. Never optimize on this portion and then call it out-of-sample.')
    import json
    print(json.dumps(summary(deals),indent=2))
    if deals:print('Trades:',a.output)

if __name__=='__main__':main()
