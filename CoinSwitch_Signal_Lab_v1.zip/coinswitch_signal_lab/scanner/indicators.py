"""Indicators calculated exclusively on fully closed OHLCV candles."""
from dataclasses import dataclass
import math
from typing import List


@dataclass(frozen=True)
class Candle:
    start_ms: int
    close_ms: int
    o: float
    h: float
    l: float
    c: float
    v: float


def ema(values, length):
    out = [None] * len(values)
    if len(values) < length:
        return out
    seed = sum(values[:length]) / length
    out[length-1] = seed
    alpha = 2 / (length+1)
    for i in range(length, len(values)):
        out[i] = alpha*values[i]+(1-alpha)*out[i-1]
    return out


def rsi(values, length=14):
    out = [None] * len(values)
    if len(values) <= length:
        return out
    gains = [max(values[i]-values[i-1], 0) for i in range(1,len(values))]
    losses = [max(values[i-1]-values[i],0) for i in range(1,len(values))]
    avg_g = sum(gains[:length])/length
    avg_l = sum(losses[:length])/length
    def score(g, l):
        return 50.0 if (g == 0 and l == 0) else (100.0 if l == 0 else 100-100/(1+g/l))
    out[length] = score(avg_g, avg_l)
    for i in range(length+1,len(values)):
        avg_g = (avg_g*(length-1)+gains[i-1])/length
        avg_l = (avg_l*(length-1)+losses[i-1])/length
        out[i] = score(avg_g,avg_l)
    return out


def atr(candles, length=14):
    n=len(candles)
    out=[None]*n
    if n < length:
        return out
    tr=[]
    for i,c in enumerate(candles):
        tr.append(c.h-c.l if i==0 else max(c.h-c.l, abs(c.h-candles[i-1].c),abs(c.l-candles[i-1].c)))
    prev=sum(tr[:length])/length
    out[length-1]=prev
    for i in range(length,n):
        prev=(prev*(length-1)+tr[i])/length
        out[i]=prev
    return out


def dmi(candles,length=14):
    """Wilder +DI, -DI, ADX with 2*length-1 startup."""
    n=len(candles)
    pdi=[None]*n; mdi=[None]*n; adx=[None]*n
    if n < 2*length:
        return pdi,mdi,adx
    trs=[]; pdms=[]; mdms=[]
    for i in range(1,n):
        highmove=candles[i].h-candles[i-1].h
        lowmove=candles[i-1].l-candles[i].l
        pdms.append(highmove if highmove>lowmove and highmove>0 else 0)
        mdms.append(lowmove if lowmove>highmove and lowmove>0 else 0)
        c=candles[i]; old=candles[i-1]
        trs.append(max(c.h-c.l,abs(c.h-old.c),abs(c.l-old.c)))
    tr=sum(trs[:length]); plus=sum(pdms[:length]); minus=sum(mdms[:length]); dx=[]
    for i in range(length,n):
        if i>length:
            k=i-1
            tr=tr-tr/length+trs[k]
            plus=plus-plus/length+pdms[k]
            minus=minus-minus/length+mdms[k]
        pdi[i]=(100*plus/tr) if tr>0 else 0
        mdi[i]=(100*minus/tr) if tr>0 else 0
        s=pdi[i]+mdi[i]
        dx.append(100*abs(pdi[i]-mdi[i])/s if s else 0)
        if len(dx)==length:
            adx[i]=sum(dx)/length
        elif len(dx)>length:
            adx[i]=(adx[i-1]*(length-1)+dx[-1])/length
    return pdi,mdi,adx


def features(candles):
    close=[c.c for c in candles]
    p,m,a=dmi(candles)
    vs=[None]*len(candles)
    for i in range(20,len(candles)):
        vs[i]=sum(c.v for c in candles[i-20:i])/20
    return {'ema9':ema(close,9),'ema21':ema(close,21),'ema200':ema(close,200),
            'rsi':rsi(close),'atr':atr(candles),'plus_di':p,'minus_di':m,'adx':a,
            'volume_ma20':vs}


def cleaned_candles(response, now_ms, interval_minutes):
    data=response['data'] if isinstance(response,dict) else response
    if not isinstance(data,list):
        raise ValueError('Unexpected candle response: expected data array')
    uniq={}
    for row in data:
        st=int(row['start_time']); end=int(row.get('close_time') or st+interval_minutes*60000)
        if st+interval_minutes*60000 > now_ms-3000 or end>now_ms-3000:
            continue  # Never use an unfinished bar.
        vals=[float(row[k]) for k in ('o','h','l','c','volume')]
        if all(math.isfinite(x) for x in vals) and min(vals[:4])>0 and vals[4]>=0 and vals[1]>=max(vals[0],vals[3]) and vals[2]<=min(vals[0],vals[3]):
            uniq[st]=Candle(st,end,*vals)
    candles=[uniq[k] for k in sorted(uniq)]
    # Reject gaps near latest bars to avoid false confirmations.
    if len(candles)>=4:
        for left,right in zip(candles[-4:-1],candles[-3:]):
            if right.start_ms-left.start_ms!=interval_minutes*60000:
                raise ValueError('Candle time gap in newest data')
    return candles
