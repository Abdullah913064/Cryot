"""Download signed CoinSwitch market candles to CSV for offline replay.

Historical market data only; does not touch your exchange positions.
Verify any gaps and the start/end query behavior on your key before backtesting.
"""
import argparse
import csv
import time
from datetime import datetime,timezone
from pathlib import Path
from scanner.client import CoinSwitchClient
from scanner.indicators import cleaned_candles


def fetch_symbol(client,symbol,interval,days,out):
    now=int(time.time()*1000)
    end=now-3000
    start=end-int(days*86400*1000)
    step=interval*60000
    all_rows={}
    cursor=start
    # Use bounded time windows rather than giant single requests.
    while cursor<end:
        upper=min(end,cursor+240*step)
        response=client._get('/trade/api/v2/futures/klines',
           {'exchange':'EXCHANGE_2','symbol':symbol,'interval':str(interval),
            'start_time':str(cursor),'end_time':str(upper),'limit':'240'},kline=True)
        for c in cleaned_candles(response,now,interval):
            if start<=c.start_ms<=end:all_rows[c.start_ms]=c
        cursor=upper
    rows=[all_rows[x] for x in sorted(all_rows)]
    out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('w',newline='') as fh:
        writer=csv.writer(fh)
        writer.writerow(['start_ms','close_ms','open','high','low','close','volume'])
        for c in rows:writer.writerow([c.start_ms,c.close_ms,c.o,c.h,c.l,c.c,c.v])
    print(f'{symbol} {interval}m: {len(rows)} rows -> {out}')
    if len(rows)<250:print('WARN: incomplete/short history; do not quote win probabilities')
    return rows


def main():
    p=argparse.ArgumentParser(description='Download futures candles for off-line testing')
    p.add_argument('--symbol',required=True,help='e.g. LITUSDT')
    p.add_argument('--days',type=int,default=40)
    p.add_argument('--dir',default='data')
    a=p.parse_args()
    if not(10<=a.days<=120):raise SystemExit('Choose between 10 and 120 days')
    if not a.symbol.isascii() or not a.symbol.isalnum() or not a.symbol.upper().endswith('USDT'):
        raise SystemExit('Use symbol such as LITUSDT')
    client=CoinSwitchClient()
    for m in [60,15,5]:
        fetch_symbol(client,a.symbol.upper(),m,a.days,Path(a.dir)/f'{a.symbol.upper()}_{m}m.csv')
    print('Replay example: python -m scanner.replay --one-hour data/'+a.symbol.upper()+'_60m.csv --fifteen-minute data/'+a.symbol.upper()+'_15m.csv --five-minute data/'+a.symbol.upper()+'_5m.csv')

if __name__=='__main__':main()
